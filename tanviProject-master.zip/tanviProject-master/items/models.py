from django.db import models
from django.contrib.auth.models import User


class Category(models.Model):
    class Meta:
        db_table = 'tblcategory'

    category_name = models.CharField(max_length=50)
    status = models.IntegerField()


# Create your models here.
class Item(models.Model):
    class Meta:
        db_table = 'tblitem'
    category = models.ForeignKey(to=Category, null=True, default=None, on_delete=models.CASCADE)
    filename = models.FileField(blank=False, name=False, upload_to='documents/', default='https://cdn.shopify.com/s/files/1/0533/2089/files/placeholder-images-image_large.png?format=jpg&quality=90&v=1530129081')
    itemname = models.CharField(max_length=50, blank=False)
    itemdesc = models.CharField(max_length=80)
    startbiddate = models.DateTimeField()
    endbiddate = models.DateTimeField()
    startbidprice = models.FloatField()
    status = models.IntegerField()


class Bid(models.Model):
    class Meta:
        db_table = 'tblbid'

    user = models.ForeignKey(to=User, null=True, default=None, on_delete=models.CASCADE)
    currenttime = models.DateTimeField(auto_now=True)
    placedbid = models.FloatField()
    itemid = models.ForeignKey(to=Item, null=True, default=None, on_delete=models.CASCADE)


class Winners(models.Model):
    class Meta:
        db_table = 'tblwinners'

    user = models.ForeignKey(to=User, null=True, default=None, on_delete=models.CASCADE)
    bid = models.ForeignKey(to=Bid, null=True, default=None, on_delete=models.CASCADE)
    currenttime = models.DateTimeField(auto_now=True)
