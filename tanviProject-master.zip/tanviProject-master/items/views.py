from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import *
from . models import *
import json


# Create your views here.
class ManageCategory(APIView):

    def get(self, request):
        cat_serializer = CategoryModelSer(instance=Category.objects.all(), many=True)
        return Response(data=cat_serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        cat_serializer = CategoryModelSer(data=request.data, partial=True)
        if cat_serializer.is_valid():
            added_item = cat_serializer.save()
            return Response(data=cat_serializer.to_representation(added_item), status=status.HTTP_201_CREATED)
        return Response(data={'errors': cat_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# Create your views here.
class ManageItems(APIView):

    def get(self, request):
        item_serializer = ItemsModalSer(instance=Item.objects.all(), many=True)
        return Response(data=item_serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        item_serializer = ItemsModalSer(data=request.data, partial=True)
        if item_serializer.is_valid():
            added_item = item_serializer.save()
            return Response(data=item_serializer.to_representation(added_item), status=status.HTTP_201_CREATED)
        return Response(data={'errors': item_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class ManageBids(APIView):

    def get(self, request):
        bid_serializer = BidModalSer(instance=Item.objects.all(), many=True)
        return Response(data=bid_serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        bid_serializer = BidModalSer(data=request.data, partial=True)
        if bid_serializer.is_valid():
            added_item = bid_serializer.save()
            return Response(data=bid_serializer.to_representation(added_item), status=status.HTTP_201_CREATED)
        return Response(data={'errors': bid_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class ManageWinners(APIView):

    def get(self, request):
        winner_serializer = BidModalSer(instance=Item.objects.all(), many=True)
        return Response(data=winner_serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        winner_serializer = BidModalSer(data=request.data, partial=True)
        if winner_serializer.is_valid():
            added_item = winner_serializer.save()
            return Response(data=winner_serializer.to_representation(added_item), status=status.HTTP_201_CREATED)
        return Response(data={'errors': winner_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
