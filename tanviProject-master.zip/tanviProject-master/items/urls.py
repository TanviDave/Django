from .views import *
from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns


urlpatterns = [
    url(r'category/$', ManageCategory.as_view()),
    url(r'items/$', ManageItems.as_view()),
    url(r'bids/$', ManageBids.as_view()),
    url(r'winners/$', ManageWinners.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
