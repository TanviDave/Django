from rest_framework.serializers import ModelSerializer
from .models import *


class CategoryModelSer(ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class ItemsModalSer(ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'


class BidModalSer(ModelSerializer):
    class Meta:
        model = Bid
        fields = '__all__'


class WinnerModalSer(ModelSerializer):
    class Meta:
        model = Winners
        fields = '__all__'
