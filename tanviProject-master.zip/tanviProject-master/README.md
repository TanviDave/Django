# tanviProject

1) clone the project
2) create a virtual-environment
3) activate virtual-environment
4) run command: pip install -r requirements.txt
5) run the project: python manage.py runserver
6) to access admin site: http://localhost:8000/admin
credentials: username: admin password:Tanvi@123
